# Create Modules By @xtsea
from pyrogram import *

PREFIX = [".", "?", "!", "*"]

cmd = [".", "?", "!", "*"] # cmd custom

command = filters.command

dont_know = -1001608701614
