<p align="center"> 〆 ᴅᴀʀᴇᴇɴ - ᴜsᴇʀʙᴏᴛ 〆 </p>

<p align="center">
  <img src="https://telegra.ph//file/be58a5cccf23b0af3382e.jpg">

<p align="center">
    <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>


## VPS/Locally deploy!
```console
 $ sudo apt-get update -y
 $ sudo apt-get upgrade
 $ git clone https://github.com/mikeel-ye/Dareen-Userbot
 $ cd Dareen-Userbot
 $ python3 -m venv venv
 $ source venv/bin/act*
 $ pip3 install -U-r req*
 $ cp sample.env .env
```

<h3 align="center">
   Edit <b>.env</b> ISI VARS YANG DIMINTA
</h3>

```console
 $ screen -S Uputt
 $ python3 -m Uputt
```

## Heroku Deploy!
<h3 align="center">Click The Button</h3>
<a href="https://heroku.com/deploy?template=https://github.com/mikeel-ye/Dareen-Userbot"><img src="https://www.herokucdn.com/deploy/button.svg"></a>
</div>

<p align="center">
  <img src="https://telegra.ph//file/1900737a5d46bbae73304.jpg">


## Thanks to 
- [Zaid](https://github.com/ITZ-ZAID)
- [OnlyMeriz](https://github.com/Onlymeriz)
- [Kazu](https://github.com/ionmusic)
- [Uputt](https://github.com/iamuput)
- [Dareen](https://github.com/mikeel-ye)

## Credit 
- Zaid Userbot
- PyroMAN
- Ayra X Userbot
- Kazu
- Geez|Ram
- Iamuput
- Dareen
## Support / Channel

<p align="center">𝐒𝐮𝐩𝐩𝐨𝐫𝐭 / 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 ----> </p>

<p align="center"><a href="https://t.me/skandallgua"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-Channel-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>
<p align="center"><a href="https://t.me/dareensupport"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐒𝐮𝐩𝐩𝐨𝐫𝐭-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>


<b>dan semua [contributor](https://github.com/mikeel-ye/Dareen-Userbot/graphs/contributors) minimal terima kasih sama dareen dan para contributor ya asu </b>

━━━━━━━━━━━━━━━━━━━━